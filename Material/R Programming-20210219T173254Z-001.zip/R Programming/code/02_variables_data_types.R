area_circle3.14 <- 20
area_circle3.14

.area_circle <- 12
.area_circle

5area_circle <- 10
.5area_circle <- 10

area.4circle <- 13
area.4circle

area.circle <- 14
area.circle

area_circle <- 21
area_circle

area_circle@ <- 10
_area_circle <- 10



var1 <- 23.5
print(class(var1))

var2 <- 34L
print(class(var2))

var3 <- "Hello World!"
print(class(var3))

var4 <- TRUE 
print(class(var4))

var5 <- 2 + 5i
print(class(var5))

var6 <- charToRaw("Hello")
print(class(var6))
print(var6)

.var7 <- 24.5
.var7

var1 <- 2 + 10i
print(class(var1))

ls()
ls(pattern = "var")
ls(all.names = TRUE)

var8 <- ls()
var8
typeof(var8)
class(var8)

var9 <- 29L

is.numeric(var9)
is.integer(var9)

is.character(var9)
var10 <- as.character(var9)
is.numeric(var10)
is.character(var10)

print(b)
rm(b)
print(b)

print(ls())
rm(list = ls())
print(ls())

ls(all.names = TRUE)
rm(list = ls(all.names = TRUE))
ls(all.names = TRUE)
