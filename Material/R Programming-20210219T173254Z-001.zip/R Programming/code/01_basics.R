a <- 5
b = 6
a + b -> c
c

d <<- c
d
print(d)
cat(d)

print(d) + 4
cat(d) + 4 

x <- 11
y <- 12

z <- x * y

radius <- 5
area_circle <- pi * radius ** 2
area_circle2 <- pi * radius ^ 2
area_circle
area_circle2

num1 <- as.integer(readline("Enter the first number: "))
num2 <- as.integer(readline("Enter the second number: "))

ans <- num1 * num2
ans

{num3 <- as.integer(readline("Enter the first number: "));num4 <- as.integer(readline("Enter the second number: "))}

ans1 <- num3 * num4
ans1

df <- read.csv('../titanic.csv', header = TRUE, stringsAsFactors = FALSE)
head(df, 10)
str(df)

plot(1:10)

#Assignment #1
#Take input from the user and calculate the area of triangle
